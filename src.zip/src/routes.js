import {createStackNavigator} from 'react-navigation';

import Main from './pages/main'
import sel from './pages/sel'

export default createStackNavigator({
   princ: Main,
   sel: sel
},{
    navigationOptions:{
        headerStyle:{
            backgroundColor: "#DA552f"
        },
        headerTintColor:"#FFF"
    }
});