import React, {Component} from 'react';
import { Alert,Button,FlatList,TouchableHighlight,ScrollView, Text, View} from 'react-native';

const obj = [{
    id:100,
    nome:"opc1",
    opc:[{id:1,valor:"a1"},{id:2,valor:"a2"},{id:3,valor:"a3"}]
},
{
    id:200,
    nome:"opc2",
    opc:[{id:4,valor:"ab1"},{id:5,valor:"ab2"},{id:6,valor:"ab3"}]
}]

var prod = [
    {
        id:100,
        valor:'a'
    },
    {
        id:200,
        valor:'b'
    }

]

export default class App extends Component {

    constructor(props){
        super(props)

        this.state= {
            res: 'testeabc',
            prod: prod
        }
    }



    mudar = (index,val) => {
    //    Alert.alert("AA")
        const p = Object.assign({}, this.state.prod)
        console.log(p)
        p[index] = val
        this.setState(state=>({
            prod:p
        }))
    }

    callback(index,val){

    }
    
    render() { 
    const { navigate } = this.props.navigation;
      return (
        <View>
          <ScrollView>
              <Text>{this.state.res}</Text>
          {obj.map((item, index) => {
            return(
              <TouchableHighlight
              onPress={()=>navigate('sel',{callback:this.mudar.bind(this),itemindex:index,p:item})}
              key={index}>
                <View>
                  <Text >{index}-{item.nome}-{this.state.prod[index].id}</Text>
                </View>
              </TouchableHighlight>
            );
          })}
          <TouchableHighlight
              onPress={()=>this.mudar(0,{id:500,valor:'jabuti'})}
              >
                <View>
                  <Text >TESTE</Text>
                </View>
              </TouchableHighlight>
        </ScrollView>
        </View>
      );
    }
  }