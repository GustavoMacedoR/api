import React, { Component } from 'react';
import { Alert, Text, Button, View, FlatList } from 'react-native';

export default class sel extends Component {


    constructor(props) {
        super(props)

        this.state = {
            res: {
                id: 100,
                nome: "opc1",
                opc: [{ id: 1, nome: "x" }, { id: 2, nome: "y" }, { id: 3, nome: "z" }]
            }
        }

    }
    render() {
        const { navigation } = this.props;
        const opcoes = navigation.getParam('p');
        const call = navigation.getParam('callback');
        const itemindex = navigation.getParam('itemindex');
        return (
            <View>
                <Text> teste</Text>
                {opcoes.opc.map((item, index) => {
                    return (
                        <View>
                            <Button title={item.valor}
                                onPress={() => {
                                    call(itemindex, item)
                                    navigation.goBack()
                                }
                                } />
                            <Text>teste</Text>
                        </View>
                    )
                })}

            </View>

        );
    }
}